let carros = [];
let pessoas = [];
let nuvens = [];
let modoNoite = false;

function setup() {
  createCanvas(800, 400);

  // Carros
  for (let i = 0; i < 3; i++) {
    carros.push({ x: random(width), y: 320, vel: random(1, 3), cor: color(random(255), random(255), random(255)) });
  }

  // Pessoas
  for (let i = 0; i < 5; i++) {
    pessoas.push({ x: random(width), y: 360, vel: random(0.5, 1.5) });
  }

  // Nuvens
  for (let i = 0; i < 3; i++) {
    nuvens.push({ x: random(width), y: random(50, 150), vel: random(0.3, 1) });
  }
}

function draw() {
  if (modoNoite) {
    background(20, 24, 82); // noite
  } else {
    background(135, 206, 235); // dia
  }

  desenharSolOuLua();
  desenharNuvens();
  desenharPredios();
  desenharRua();
  desenharCarros();
  desenharPessoas();
}

function desenharSolOuLua() {
  if (modoNoite) {
    fill(255, 255, 200);
  } else {
    fill(255, 204, 0);
  }
  noStroke();
  ellipse(700, 80, 60);
}

function desenharNuvens() {
  fill(255);
  noStroke();
  for (let n of nuvens) {
    ellipse(n.x, n.y, 60, 40);
    ellipse(n.x + 20, n.y + 10, 50, 30);
    ellipse(n.x - 20, n.y + 10, 50, 30);
    n.x += n.vel;
    if (n.x > width + 50) n.x = -50;
  }
}

function desenharPredios() {
  for (let i = 0; i < width; i += 100) {
    fill(100, 100, 150);
    rect(i, 200, 80, 200);
    // Janelas
    if (modoNoite) {
      fill(255, 255, 100);
    } else {
      fill(220);
    }
    for (let y = 220; y < 380; y += 30) {
      rect(i + 20, y, 10, 10);
      rect(i + 50, y, 10, 10);
    }
  }
}

function desenharRua() {
  fill(50);
  rect(0, 300, width, 100);
  // Faixa
  fill(255);
  for (let i = 0; i < width; i += 40) {
    rect(i, 340, 20, 5);
  }
}

function desenharCarros() {
  for (let c of carros) {
    fill(c.cor);
    rect(c.x, c.y, 50, 20);
    fill(0);
    ellipse(c.x + 10, c.y + 20, 10);
    ellipse(c.x + 40, c.y + 20, 10);
    c.x += c.vel;
    if (c.x > width) c.x = -60;
  }
}

function desenharPessoas() {
  fill(0);
  for (let p of pessoas) {
    ellipse(p.x, p.y - 20, 10); // cabeça
    rect(p.x - 5, p.y - 15, 10, 20); // corpo
    p.x += p.vel;
    if (p.x > width) p.x = -10;
  }
}

// === Interatividade ===

// Clique para adicionar carro ou pessoa
function mousePressed() {
  if (mouseY > 300 && mouseY < 400) {
    // Adiciona carro
    carros.push({
      x: mouseX,
      y: 320,
      vel: random(1, 3),
      cor: color(random(255), random(255), random(255))
    });
  } else if (mouseY > 340 && mouseY < 380) {
    // Adiciona pessoa
    pessoas.push({
      x: mouseX,
      y: 360,
      vel: random(0.5, 1.5)
    });
  }
}

// Tecla "n" para mudar o modo dia/noite
function keyPressed() {
  if (key === 'n' || key === 'N') {
    modoNoite = !modoNoite;
  }
}